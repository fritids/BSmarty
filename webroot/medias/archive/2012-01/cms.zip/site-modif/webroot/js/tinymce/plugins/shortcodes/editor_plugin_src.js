/**
 * editor_plugin_src.js
 *
 * Copyright 2009, Moxiecode Systems AB
 * Released under LGPL License.
 *
 * License: http://tinymce.moxiecode.com/license
 * Contributing: http://tinymce.moxiecode.com/contributing
 */

(function() {

	tinymce.create('tinymce.plugins.ShortcodesPlugin', {
		/**
		 * Initializes the plugin, this will be executed after the plugin has been created.
		 * This call is done before the editor instance has finished it's initialization so use the onInit event
		 * of the editor instance to intercept that event.
		 *
		 * @param {tinymce.Editor} ed Editor instance that the plugin is initialized in.
		 * @param {string} url Absolute URL to where the plugin is located.
		 */
		init : function(ed, url) {
			// Register the command so that it can be invoked by using tinyMCE.activeEditor.execCommand('mceExample');
			ed.addButton('CMlayouts', {
				title : 'Layouts Shortcode',
				image : url+'/images/layout-shortcodes.png', 
				onclick : function() {
					ed.windowManager.open({
						file : url + '/pages/shortcodes_popup.php?section=layouts',
						width : 540,
						height : 350,
                              title: 'Layouts Selection',
						inline : 1	
					});
				}
			});

			/*ed.addButton('CMSstyling', {
				title : 'Quick Styling',
				image : url+'/images/styling-shortcodes.png', 
				onclick : function() {
					ed.windowManager.open({
						file : url + '/pages/rt_shortcodes_popup.php?section=styling',
						width : 640,
						height : 350,
                              title: 'Quick Styling',
						inline : 1
					});
				}
			});*/

			ed.addButton('CMSbuttons', {
				title : 'Buttons Shortcode',
				image : url+'/images/button-shortcodes.png', 				
				onclick : function() {
					ed.windowManager.open({
						file : url + '/pages/shortcodes_popup.php?section=buttons',
						width : 570,
						height : 500,
                              title: 'Buttons',
						inline : 1
					});
				}
			});

			/*ed.addButton('CMScontactform', {
				title : 'RT-Theme Contact Form Shortcode ',
				image : url+'/images/mail-open.png',
				onclick : function() {
					window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '[contact_form title=\"Form Title\" email=\"youremail@yoursite.com\" text=\"Form description\"] ');
					window.tinyMCE.activeEditor.execCommand('mceRepaint');
					
						jQuery(".helpshortcode").remove();
						jQuery("#poststuff").prepend('<div class="helpshortcode"></div>');

						jQuery(".helpshortcode").hide(function() {
							jQuery(".helpshortcode").html('<div class="updated"><div class="rt-message">X</div>'
											+ '	<h2 class="rt-message-h2">Shortcode Tips</h2> '
											+ '	<hr class="rt-message-hr" /> Please Note: You can also use this shortcode with a text widget in sidebars.'
											+ '	<h4>Parameters of this shortcode</h4> '
											+ '	<ul>	'
											+ '	<li> <b>title:</b> Form title</li>	'
											+ '	<li> <b>email:</b> Write an email which you want to send the form</li>	'
											+ '	<li> <b>text:</b> The text before the form</li>	'											
											+ '	</ul></div>');						
						});
						jQuery(".helpshortcode").fadeIn('slow');
				
				}
				
			});*/

			ed.addButton('CMSslider', {
				title : 'Slider Shortcode',
				image : url+'/images/slider-shortcodes.png',
				onclick : function() {
					window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '[slider]<br />[slide image_width=\"650\" image_height=\"300\" link=\"your_link\" alt_text="check it out" title="your_title" auto_resize="true"] full url of your image [/slide] <br />[slide image_width=\"650\" image_height=\"300\" link="your_link\" alt_text="check it out" title="your_title" auto_resize="true"] full url of your image [/slide] <br />[/slider] <br /> <br /> ');
					window.tinyMCE.activeEditor.execCommand('mceRepaint');

							jQuery("#help").hide();
							jQuery(".helpshortcode").remove();
							jQuery("#help").html('<div class="helpshortcode"><div style="margin-top: 20px; padding: .7em;" class="ui-state-highlight ui-corner-all">'
									+ '<span class="ui-icon ui-icon-close closehelp" onclick=\'$(".helpshortcode").slideUp("slow", function(){ $(this).remove(); });\' style="float:right; margin: 5px; cursor: pointer;"></span>'
									+ '<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-info"></span>'
									+ '<strong>Conseil d\'utilisation :</strong> <i>Slider Shortcode</i></p>'
									+ '<p>ou can enter unlimited [slide ]..[/slide] line to add new items to your gallery.<p>'
									+ '	<ul>'
									+ '	<li> <b>image_width:</b> Image width</li>'
									+ '	<li> <b>image_height:</b> Image height</li>	'
									+ '	<li> <b>auto_resize:</b> If it\'s "true" a new image will be created automatically. Default is "true", set "false" if you want to use your orginal image.</li>	'
									+ '	<li> <b>link:</b> Write the link for the slide or leave blank.</li>	'
									+ '	<li> <b>alt_text:</b> The text for the "alt" tag.</li>'
									+ '	<li> <b>title:</b> your title</li>'
									+ '</ul>'
									+ '</div></div>');
							jQuery("#help").slideDown("slow");

				}
			});

			/*ed.addButton('CMSgallery', {
				title : 'Photo Gallery Shortcode',
				image : url+'/images/photo-gallery-shortcodes.png',
				onclick : function() {
					window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '			[photo_gallery] <br />[image thumb_width="135" thumb_height="135" lightbox="true" custom_link="" title="sample image" caption=""] full url of your image [/image] <br />[image thumb_width="135" thumb_height="135" lightbox="true" custom_link="" title="sample image" caption=""] full url of your image [/image] <br />[image thumb_width="135" thumb_height="135" lightbox="true" custom_link="" title="sample image" caption=""] full url of your image [/image] <br />[/photo_gallery] <br /> <br /> ');
					window.tinyMCE.activeEditor.execCommand('mceRepaint');

						jQuery(".helpshortcode").remove();
						jQuery("#poststuff").prepend('<div class="helpshortcode"></div>');

						jQuery(".helpshortcode").hide(function() {
							jQuery(".helpshortcode").html('<div class="updated"><div class="rt-message">X</div>'
									+ '	<h2 class="rt-message-h2">Shortcode Tips</h2> '
									+ '	<hr class="rt-message-hr" /> You can enter unlimited [image ]..[/image] line to add new items to your gallery.'
									+ '	<h4>Parameters of this shortcode</h4> '
									+ '	<ul>	'
									+ '	<li> <b>thumb_width:</b> thumbnail width</li>	'
									+ '	<li> <b>thumb_height:</b> thumbnail height</li>	'
									+ '	<li> <b>lightbox:</b> opens the big image in a lightbox</li>	'
									+ '	<li> <b>custom_link:</b> you can define another link different then the big version of the thumbnail.</li>	'
									+ '	<li> <b>caption:</b> caption text for the item.</li>	'
									+ '	<li> <b>title:</b> title text.</li>	'
									+ '	</ul></div>');						
						});
						jQuery(".helpshortcode").fadeIn('slow'); 
				}
			});*/

			/*ed.addButton('CMSlightbox', {
				title : 'Auto Thumbnail and Lightbox Shortcode',
				image : url+'/images/thumbnail-shortcodes.png',
				onclick : function() {
					window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '			[auto_thumb width="150" height="150" link="" lightbox="true" align="left" title="" alt="" iframe="false" frame="true" crop="true"] full url of your image [/auto_thumb] <br /> <br /> ');
					window.tinyMCE.activeEditor.execCommand('mceRepaint');

						jQuery(".helpshortcode").remove();
						jQuery("#poststuff").prepend('<div class="helpshortcode"></div>');

						jQuery(".helpshortcode").hide(function() {
							jQuery(".helpshortcode").html('<div class="updated"><div class="rt-message">X</div>'
									+ '	<h2 class="rt-message-h2">Shortcode Tips</h2> '
									+ '	<hr class="rt-message-hr" /> '
									+ '	<h4>Parameters of this shortcode</h4> '
									+ '	<ul>	'
									+ '	<li> <b>link:</b> you can enter custom url. If you leave blank it will be linked to the bigger version of the image. </li>	'
									+ '	<li> <b>width:</b> thumbnail width</li>	'
									+ '	<li> <b>height:</b> thumbnail height</li>	'
									+ '	<li> <b>lightbox:</b> (true/false) default is true, enter no to disable lightbox feature</li>	'
									+ '	<li> <b>title:</b> link title text.</li>	'
									+ '	<li> <b>align:</b> (left/right/center) default is left, image alignment</li>	'
									+ '	<li> <b>alt:</b> alt tag for image</li>	'
									+ '	<li> <b>iframe:</b> (true/false) default is false. Use this paramater if you want to open a page or an external url in a lightbox.</li>	'
									+ '	<li> <b>frame:</b> (true/false) default is true.  Use this paramater if you want to add a frame to the thubmnail.</li>	'
									+ '	<li> <b>crop:</b> (true/false) default is true. Crops images with the width and height values that you defined.</li>	'
									+ '	</ul></div>');						
						});
						jQuery(".helpshortcode").fadeIn('slow');
						 
				}
			});*/
 
 
			/*ed.addButton('CMSsliderscroll', {
					title : 'Scroll Slider Shortcode',
					image : url+'/images/scroll_slider.png',
					onclick : function() {
						window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '			[scroll_slider]<br />[scroll_image] full url of your image [/scroll_image] <br />[scroll_image] full url of your image [/scroll_image] <br />[scroll_image] full url of your image [/scroll_image] <br />[/scroll_slider] <br /> <br /> ');
						window.tinyMCE.activeEditor.execCommand('mceRepaint');
	
							jQuery(".helpshortcode").remove();
							jQuery("#poststuff").prepend('<div class="helpshortcode"></div>');
	
							jQuery(".helpshortcode").hide(function() {
								jQuery(".helpshortcode").html('<div class="updated"><div class="rt-message">X</div>'
										+ '	<h2 class="rt-message-h2">Shortcode Tips</h2> ' 
										+ '	<hr class="rt-message-hr" /> '
										+ '	<p>Paste image urls in the [scroll_image][/scroll_image] breckets which has been uploaded by the media uploader before. i.e., your images must be local for the site. '
										+ '	</p></div>');											
							});
							jQuery(".helpshortcode").fadeIn('slow');
							 
					}
				});*/
 
			ed.addButton('CMStabs', {
					title : 'Tabs Shortcode',
					image : url+'/images/tab-shortcodes.png',
					onclick : function() {
						window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '			[tabs align="horizontal" tab1="Tab 1" tab2="Tab 2" tab3="Tab 3"]<br />[tab id="tab1"]Tab 1 Content [/tab]<br />[tab id="tab2"]Tab 2 Content[/tab]<br />[tab id="tab3"]Tab 3 Content [/tab]<br />[/tabs]<br /> <br /> ');
						window.tinyMCE.activeEditor.execCommand('mceRepaint');
							
							jQuery("#help").hide();
							jQuery(".helpshortcode").remove();
							jQuery("#help").html('<div class="helpshortcode"><div style="margin-top: 20px; padding: .7em;" class="ui-state-highlight ui-corner-all">'
									+ '<span class="ui-icon ui-icon-close closehelp" onclick=\'$(".helpshortcode").slideUp("slow", function(){ $(this).remove(); });\' style="float:right; margin: 5px; cursor: pointer;"></span>'
									+ '<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-info"></span>'
									+ '<strong>Conseil d\'utilisation :</strong> <i>Tabs Shortcode</i></p>'
									+ '<p>Put tab contents into the [tab][/tab] breckets. For the tab titles use the first bracket parameters like  [tabs tab1="Tab 1" tab2="Tab 2" tab3="Tab 3"] . There is no tab limit, you can add tabs till the fit your page.<p>'
									+ '<p>tab : horizontal or vertical</p>'
									+ '</div></div>');
							jQuery("#help").slideDown("slow");
							 
					}
				});

			ed.addButton('CMStable', {
					title : 'Table Shortcode',
					image : url+'/images/table-shortcodes.png',
					onclick : function() {
						window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '			[table col1="Title 1" col2="Title 2" col3="Title 3"]<br />[line][col]Content line 1 col 1 [/col]<br />[col]Content line 1 col 2 [/col]<br />[col]Content line 1 col 3 [/col][/line]<br />[line][col]Content line 2 col 1 [/col]<br />[col]Content line 2 col 2 [/col]<br />[col]Content line 2 col 3 [/col][/line]<br/>[line][col]Content line 3 col 1 [/col]<br />[col]Content line 3 col 2 [/col]<br />[col]Content line 3 col 3 [/col][/line][/table]<br /> <br /> ');
						window.tinyMCE.activeEditor.execCommand('mceRepaint');
							
							jQuery("#help").hide();
							jQuery(".helpshortcode").remove();
							jQuery("#help").html('<div class="helpshortcode"><div style="margin-top: 20px; padding: .7em;" class="ui-state-highlight ui-corner-all">'
									+ '<span class="ui-icon ui-icon-close closehelp" onclick=\'$(".helpshortcode").slideUp("slow", function(){ $(this).remove(); });\' style="float:right; margin: 5px; cursor: pointer;"></span>'
									+ '<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-info"></span>'
									+ '<strong>Conseil d\'utilisation :</strong> <i>Table Shortcode</i></p>'
									+ '<p>To start the table use [table][/table] breckets. To make a line [line][/line]. Then, put your content into [col][/col] breckets. There is no table limit, line limit and col limit, but your table must be right structured.<p>'
									+ '</div></div>');
							jQuery("#help").slideDown("slow");
							 
					}
				});


			ed.addButton('CMSaccordion', {
					title : 'Accordion Shortcode',
					image : url+'/images/accordion-shortcodes.png',
					onclick : function() {
						window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '[accordion align=""]<br />[pane title="Accordion Pane 1"] content [/pane] <br />[pane title="Accordion Pane 2"] content [/pane] <br />[pane title="Accordion Pane 3"] content [/pane] <br />[/accordion]<br /><br /> ');
						window.tinyMCE.activeEditor.execCommand('mceRepaint');
							jQuery("#help").hide();
							jQuery(".helpshortcode").remove();
							jQuery("#help").html('<div class="helpshortcode"><div style="margin-top: 20px; padding: .7em;" class="ui-state-highlight ui-corner-all">'
									+ '<span class="ui-icon ui-icon-close closehelp" onclick=\'$(".helpshortcode").slideUp("slow", function(){ $(this).remove(); });\' style="float:right; margin: 5px; cursor: pointer;"></span>'
									+ '<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-info"></span>'
									+ '<strong>Conseil d\'utilisation :</strong> <i>Accordion Shortcode</i></p>'
									+ '<p>Put contents into the [pane title="Pane Title"][/pane] breckets.<br /> In order to have left or right aligned accordions you can use "align" parameter.<p>'
									+ '<p>Example: [accordion align="left"]...[/accordion] or [accordion align="right"][/accordion]</p>'
									+ '</div></div>');
							jQuery("#help").slideDown("slow");
					}
				});

			/*ed.addButton('CMStooltip', {
					title : 'Tool Tip Shortcode',
					image : url+'/images/tool_tip.png',
					onclick : function() {
						window.tinyMCE.execInstanceCommand(window.tinyMCE.activeEditor.editorId, 'mceInsertContent', false, '[tooltip text="Tooltip Text" link="" target="" color="black"]content[/tooltip]<br /><br /> ');
						window.tinyMCE.activeEditor.execCommand('mceRepaint');
	
							jQuery("#help").hide();
							jQuery(".helpshortcode").remove();
							jQuery("#help").html('<div class="helpshortcode"><div style="margin-top: 20px; padding: .7em;" class="ui-state-highlight ui-corner-all">'
									+ '<span class="ui-icon ui-icon-close closehelp" onclick=\'$(".helpshortcode").slideUp("slow", function(){ $(this).remove(); });\' style="float:right; margin: 5px; cursor: pointer;"></span>'
									+ '<p><span style="float: left; margin-right: .3em;" class="ui-icon ui-icon-info"></span>'
									+ '<strong>Conseil d\'utilisation :</strong> <i>Tips Shortcode</i></p>'
									+ '<p>Put contents into the [tooltip][/tooltip] breckets.<p>'
									+ '	<ul>'
									+ '	<li> <b>text:</b> the text you want to show in the tooltip. </li>'
									+ '	<li> <b>color:</b> (white/black)'
									+ '	<li> <b>link:</b> If you want to link the content, use this parameter.</li>'
									+ '	<li> <b>target:</b> target of the link .	ex: _blank, _parent, _self, _top </li>'
									+ '</ul>'
									+ '</div></div>');
							jQuery("#help").slideDown("slow");
							 
					}
				});*/
		},

		/**
		 * Creates control instances based in the incomming name. This method is normally not
		 * needed since the addButton method of the tinymce.Editor class is a more easy way of adding buttons
		 * but you sometimes need to create more complex controls like listboxes, split buttons etc then this
		 * method can be used to create those.
		 *
		 * @param {String} n Name of the control to create.
		 * @param {tinymce.ControlManager} cm Control manager to use inorder to create new control.
		 * @return {tinymce.ui.Control} New control instance or null if no control was created.
		 */
		createControl : function(n, cm) {
			return null;
		},

		/**
		 * Returns information about the plugin as a name/value array.
		 * The current keys are longname, author, authorurl, infourl and version.
		 *
		 * @return {Object} Name/value array containing information about the plugin.
		 */
		getInfo : function() {
			return {
				longname : 'Shortcodes plugin',
				author : 'Benjamin Cabanes',
				authorurl : 'http://slapandthink.com',
				infourl : 'http://wiki.moxiecode.com/index.php/TinyMCE:Plugins/example',
				version : "1.0"
			};
		}
	});

	// Register plugin
	tinymce.PluginManager.add('shortcodes', tinymce.plugins.ShortcodesPlugin);
})();