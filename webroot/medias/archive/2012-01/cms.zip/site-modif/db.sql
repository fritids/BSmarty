-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Ven 20 Janvier 2012 à 16:45
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `groupeforum_cms`
--
CREATE DATABASE `groupeforum_cms` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `groupeforum_cms`;

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `type`) VALUES
(1, 'catégorie 1', 'categorie-1', 'post'),
(2, 'Seconde catégorie', 'seconde-categorie', 'page'),
(3, 'La nouvelle catégorie', 'la-nouvelle-categorie', 'post'),
(5, '', '', 'unknown');

-- --------------------------------------------------------

--
-- Structure de la table `configs`
--

CREATE TABLE IF NOT EXISTS `configs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `category` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug_UNIQUE` (`slug`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `configs`
--

INSERT INTO `configs` (`id`, `name`, `slug`, `value`, `category`) VALUES
(1, 'Title', 'site_title', 'Titre du site', 'admin_general'),
(2, 'Slogan', 'site_slogan', 'Le slogan de mon site', 'admin_general'),
(3, 'Keywords', 'site_keywords', 'mot 1, mot 2, mot 3', 'admin_general'),
(4, 'Description', 'site_description', 'Une seule phrase de description succinte du site, pour le référencement.', 'admin_general'),
(5, 'emailTo', 'emailto', 'contact.bcabanes@gmail.com', 'admin_general'),
(6, 'emailFrom', 'emailfrom', 'bcabanes@groupeforum.net', 'admin_general');

-- --------------------------------------------------------

--
-- Structure de la table `medias`
--

CREATE TABLE IF NOT EXISTS `medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `medias`
--

INSERT INTO `medias` (`id`, `name`, `file`, `post_id`, `type`) VALUES
(1, 'Mon image', '2011-10/cadeaux.jpg', 16, 'image'),
(2, 'Casque', '2011-10/casque.jpg', 3, 'image'),
(5, 'Mon word pour le boulot', '2012-01/test.doc', 0, 'word');

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_cat` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` text,
  `created` datetime DEFAULT NULL,
  `online` int(11) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Contenu de la table `posts`
--

INSERT INTO `posts` (`id`, `id_cat`, `name`, `content`, `created`, `online`, `type`, `slug`, `user_id`) VALUES
(1, 2, 'Ma première page', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.</p>\r\n<p>[tabs align="horizontal" tab1="Small" tab2="Medium" tab3="Large"]<br />[tab id="tab1"]Lorem ipsum dolor sit amet, consectetur adipiscing elit.&nbsp;Lorem ipsum dolor sit amet, consectetur adipiscing elit.[/tab]<br />[tab id="tab2"]Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor sit amet, consectetur adipiscing elit.[/tab]<br />[tab id="tab3"]Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit.[/tab]<br />[/tabs]</p>\r\n<p>[accordion align="center"]<br />[pane title="Titre 1"] Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.[/pane] <br />[pane title="Titre 2"] Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.[/pane] <br />[pane title="Titre 3"] Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.[/pane] <br />[/accordion]</p>\r\n<p>&nbsp;</p>\r\n<p>[tabs align="vertical" tab1="Tab 1" tab2="Tab 2" tab3="Tab 3"]<br />[tab id="tab1"]Tab 1 Content [/tab]<br />[tab id="tab2"]Tab 2 Content[/tab]<br />[tab id="tab3"]Tab 3 Content [/tab]<br />[/tabs]</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>[table col1="Title 1" col2="Title 2" col3="Title 3"]<br />[line][col]Content line 1 col 1 [/col]<br />[col]Content line 1 col 2 [/col]<br />[col]Content line 1 col 3 [/col][/line]<br />[line][col]Content line 2 col 1 [/col]<br />[col]Content line 2 col 2 [/col]<br />[col]Content line 2 col 3 [/col][/line]<br />[line][col]Content line 3 col 1 [/col]<br />[col]Content line 3 col 2 [/col]<br />[col]Content line 3 col 3 [/col][/line][/table]</p>\r\n<p>&nbsp;</p>\r\n<p>[table col1="Title 1" col2="Title 2" col3="Title 3" col4="Title 4" col5="Title 5" col6="Title 6" col7="Title 7" col8="Title 8" col9="Title 9" col10="Title 10"]<br />[line][col]Content line 1 col 1 [/col]<br />[col]Content line 1 col 2 [/col]<br />[col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][/line]<br />[line][col]Content line 2 col 1 [/col]<br />[col]Content line 2 col 2 [/col]<br />[col]Content line 2 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][/line]<br />[line][col]Content line 3 col 1 [/col]<br />[col]Content line 3 col 2 [/col]<br />[col]Content line 3 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][col]Content line 1 col 3 [/col][/line][/table]</p>', '2011-10-20 00:00:00', 1, 'page', 'ma-premiere-page', 0),
(2, 2, 'Ma seconde page', '<p>[slider]<br />[slide image_width="" image_height="" link="http://www.google.ca" alt_text="Utiliser Google ?" title="Premi&egrave;re slide" auto_resize="true"]<span class="url">http://lorempixel.com/940/246/sports</span>[/slide] <br />[slide image_width="" image_height="" link="http://www.slapandthink.com" alt_text="My personal Blog" title="Titre 2 : je sais pas quoi mettre ..." auto_resize="true"]<span class="url">http://lorempixel.com/940/246/fashion/8</span>[/slide]</p>\r\n<p>[slide image_width="" image_height="" link="#" alt_text="Encore un caption" title="Blop?" auto_resize="true"]<span class="url">http://lorempixel.com/940/246/fashion</span>/6[/slide]</p>\r\n<p>[slide image_width="" image_height="" link="#" alt_text="Et de 4 !" title="J''aime quand &ccedil;a pique !" auto_resize="true"]<span class="url">http://lorempixel.com/940/246/fashion</span>/7[/slide]<br />[/slider]</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.</p>', '2011-10-21 00:00:00', 1, 'page', 'ma-seconde-page', 0),
(3, 1, 'Mon premier post', '<p><a href="/dev/tuto/site/post/mon-premier-post-3"><img style="margin-left: 10px; margin-right: 10px; float: left;" title="Mon casque" src="/dev/tuto/ga/site-modif/medias/image/2011-10/casque.jpg" alt="" width="200" height="150" /></a>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.</p>', '2011-10-26 04:01:03', 1, 'post', 'mon-premier-post', 0),
(17, 3, 'datepicker', '<p>Quibus ita sceleste patratis Paulus cruore perfusus reversusque ad principis castra multos coopertos paene catenis adduxit in squalorem deiectos atque maestitiam, quorum adventu intendebantur eculei uncosque parabat carnifex et tormenta. et ex is proscripti sunt plures actique in exilium alii, non nullos gladii consumpsere poenales. nec enim quisquam facile meminit sub Constantio, ubi susurro tenus haec movebantur, quemquam absolutum.</p>', '2011-10-31 03:36:34', 1, 'post', 'datepicker', NULL),
(12, 3, 'Mon article d''édition UPDATE ''', '<p>Mon nouveau contenu</p>', '2011-10-26 12:52:49', 1, 'post', 'mon-article-edition', NULL),
(13, 1, 'Mon nouveau article', '<p>Mon nouveau contenu</p>', '2011-10-26 12:25:59', 1, 'post', 'mon-nouveau-article', NULL),
(14, 1, 'Mon premier post test', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales elit non erat sodales ultricies. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam vulputate nunc id lorem semper sollicitudin. Aenean quis diam et dui facilisis tempus nec eu velit. Nulla iaculis lacus sit amet nibh mattis fringilla feugiat nunc commodo. Sed aliquet mi sed tortor mollis euismod. Mauris ligula felis, aliquet id porttitor non, semper nec elit. Morbi nisl nunc, ultrices vel accumsan sit amet, pretium nec elit.</p>', '2011-10-26 12:26:19', 1, 'post', 'mon-premier-post-test', NULL),
(15, 2, 'Encore un nouvel article', '<p>Encore du contenu, mais cette fois ci, il est en <strong>gras</strong>.</p>', '2011-10-26 12:48:34', 1, 'post', 'encore-un-nouvel-article', NULL),
(16, 2, 'Mon article INSERT', '<p>Je met du <strong>contenu</strong></p>\r\n<ul>\r\n<li>liste</li>\r\n<li>deux</li>\r\n</ul>\r\n<ol>\r\n<li>liste</li>\r\n<li>trois</li>\r\n</ol>\r\n<p>&nbsp;</p>', '2011-10-26 01:35:55', 1, 'post', 'mon-article-insert', NULL),
(21, 2, 'Mentions Légales', '<p>&nbsp;</p>\r\n<p>&nbsp; <a class="button small default" href="/dev/tuto/ga/site-modif/medias/image/2011-10/cadeaux.jpg"><span class="mail dark">Mail Button</span></a> <a class="button small light">Small Button</a> <a class="button medium light">Medium Button</a> <a class="button big light">Big Button</a></p>\r\n<p><a class="button small default">Small Button</a> <a class="button medium default">Medium Button</a> <a class="button big default">Big Button</a> <a class="button small default"><span class="mail dark">Mail Button</span></a></p>\r\n<p><a class="button small orange">Small Button</a> <a class="button medium orange">Medium Button</a> <a class="button big orange">Big Button</a> <a class="button small orange"><span class="mail light">Mail Button</span></a></p>\r\n<p><a class="button small blue">Small Button</a> <a class="button medium blue">Medium Button</a> <a class="button big blue">Big Button</a> <a class="button small blue"><span class="mail light">Mail Button</span></a></p>\r\n<p><a class="button small dark">Small Button</a> <a class="button medium dark">Medium Button</a> <a class="button big dark">Big Button</a> <a class="button small dark"><span class="mail light">Mail Button</span></a></p>\r\n<p><a class="button small green">Small Button</a> <a class="button medium green">Medium Button</a> <a class="button big green">Big Button</a> <a class="button small green"><span class="mail light">Mail Button</span></a></p>\r\n<p><a class="button small red">Small Button</a> <a class="button medium red">Medium Button</a> <a class="button big red">Big Button</a> <a class="button small red"><span class="mail light">Mail Button</span></a></p>\r\n<p>&nbsp;</p>\r\n<div class="boxes row">\r\n<div class="box span8 first">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n<div class="box span8 last">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n</div>\r\n<p>&nbsp;</p>\r\n<p>Sed ut tum ad senem senex de senectute, sic hoc libro ad amicum amicissimus scripsi de amicitia. Tum est Cato locutus, quo erat nemo fere senior temporibus illis, nemo prudentior; nunc Laelius et sapiens (sic enim est habitus) et amicitiae gloria excellens de amicitia loquetur. Tu velim a me animum parumper avertas, Laelium loqui ipsum putes. C. Fannius et Q. Mucius ad socerum veniunt post mortem Africani; ab his sermo oritur, respondet Laelius, cuius tota disputatio est de amicitia, quam legens te ipse cognosces.</p>\r\n<p>&nbsp;</p>\r\n<div class="boxes row">\r\n<div class="box span-one-third first">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n<div class="box span-one-third">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n<div class="box span-one-third last">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n</div>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<div class="boxes row">\r\n<div class="box span14 first">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n<div class="box span2 last">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div class="boxes row">\r\n<div class="box span12 first">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n<div class="box span4 last">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n</div>\r\n<p>&nbsp;</p>\r\n<div class="boxes row">\r\n<div class="box span-two-thirds first">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n<div class="box span-one-third last">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</div>\r\n</div>', '2011-11-02 04:39:18', 1, 'page', 'mentions-legales', NULL),
(22, 0, NULL, NULL, NULL, -1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `trees`
--

CREATE TABLE IF NOT EXISTS `trees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `lft` int(11) NOT NULL,
  `rght` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Contenu de la table `trees`
--

INSERT INTO `trees` (`id`, `name`, `lft`, `rght`) VALUES
(9, 'Opérateur mobile', 40, 59),
(23, 'SFR', 57, 58),
(24, 'Orange', 51, 54),
(25, 'Virgin Mobile', 41, 42),
(27, 'Numericable', 39, 60),
(28, 'Sosh', 52, 53),
(29, 'Bouygues Telecom', 45, 50),
(30, 'Be & You', 47, 48),
(32, 'Free', 55, 56),
(33, 'Test', 46, 49),
(34, 'Test2', 43, 44);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `role`) VALUES
(1, 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', 'admin');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
