<?php

	class Post extends Model {
		
		var $validates = array(
			'name' => array(
				'rule' => 'notEmpty',
				'message' => 'Vous devez préciser un titre'
			),
			'slug' => array(
				'rule' => '([a-z0-9\-]+)',
				'message' => "L'url n'est pas valide"
			)
		);



		function excerpt($posts, $length=250, $trailing="...") {

			$length -= mb_strlen($trailing);

			foreach($posts as $k){
				if(mb_strlen($k->content)> $length){
					// string exceeded length, truncate and add trailing dots
					$k->excerpt = mb_substr($k->content,0,$length).$trailing;
				}else{
					$k->excerpt = $k->content;
				}
			}

			return ;
		}


	}

?>