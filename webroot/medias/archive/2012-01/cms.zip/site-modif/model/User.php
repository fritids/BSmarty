<?php

	class User extends Model {

	}

?>