<?php

	class ThemeShortcode extends Shortcode {

		/*
		* ------------------------------------------------- *
		*		Tabular Content
		* ------------------------------------------------- *
		*/
		function tabulars($atts, $content = null ) {
			// [tabs align="" tab1="" tab2="" tab3=""][/tabs]

			$tabs = "";
			$content = $this->do_shortcode($content);	
			$content = $this->fixshortcode($content);
			$content = preg_replace('#<br \/>#', "",trim($content));
			$content = preg_replace('#<p>#', "",trim($content));
			$content = preg_replace('#<\/p>#', "",trim($content)); 

			if($atts['align'] == "vertical"){
				$class = "ui-tabs-vertical";
			}else{
				$class = "";
			}
			unset($atts['align']);

		    for($i=1;$i<count($atts)+1;$i++){
		        $tab_name = $atts['tab'.$i];
		        if($tab_name){
		        	if($i == 1){
		        		$tabs .=   '<li><a href="#tab'.$i.'">'.$tab_name.'</a></li>';
		        	}else{
		        		$tabs .=   '<li><a href="#tab'.$i.'">'.$tab_name.'</a></li>';	
		        	}
		        }
		    }

			return '<div class="tabs '.$class.'"><ul>'.$tabs.'</ul>'.$this->do_shortcode($content).'</div>';
		}

		function tab($atts, $content = null ) {
			//[tab id="tab1"][/tab]
		    $content = $this->do_shortcode($content);	
			$content = $this->fixshortcode($content);
			$content = preg_replace('#<br \/>#', "",trim($content));
			$content = preg_replace('#<p>#', "",trim($content));
			$content = preg_replace('#<\/p>#', "",trim($content)); 
			
			$html = ' <div id="'.$atts['id'].'" >' . $content . '</div>';
			
			return $html;
		}

		/*
		* ------------------------------------------------- *
		*		Accordions
		* ------------------------------------------------- *
		*/
		function accordion($atts, $content = null) {
		    //[accordion align=""][/accordion]
		    //align
		    $align = $atts['align'];
		    if($align) $align =  'small _'.$align;
		   
		    //fix shortcode
		    $content = $this->do_shortcode($content);	
		    $content = $this->fixshortcode($content);
		    $content = preg_replace('#<br \/>#', "",trim($content));
		    $content = preg_replace('#<p>#', "",trim($content));
		    $content = preg_replace('#<\/p>#', "",trim($content)); 
		    
		    return '<div class="accordion '.$align.'">'.$this->do_shortcode($content).'</div>';
		}

		function accordion_panel($atts, $content = null) {
			//[pane title=""][/pane]
		    
		    $pane_title=$atts['title'];
			
		    //fix shortcode
		    $content = $this->do_shortcode($content);	
		    $content = $this->fixshortcode($content);
		    $content = preg_replace('#<br \/>#', "",trim($content));
		    $content = preg_replace('#<p>#', "",trim($content));
		    $content = preg_replace('#<\/p>#', "",trim($content)); 

		    return '<h3><a href="#">'.$pane_title.'</a></h3><div class="pane">' . $content . '<div class="clear"></div></div>';
		}

		/*
		* ------------------------------------------------- *
		*		Slider
		* ------------------------------------------------- *
		*/
		function slider($atts, $content = null) {
			//[slider][/slider]

			//fix content
			$content = preg_replace('#<br \/>#', "",trim($content));
			$content = preg_replace('#<p>#', "",trim($content));
			$content = preg_replace('#<\/p>#', "",trim($content));
			
		 	$content = $this->do_shortcode($content);
			$content = $this->fixshortcode($content);

			return '<div class="slider-wrapper theme-default"><div class="slider">'.$this->do_shortcode($content).'</div></div>';
		}

		function slide($atts, $content = null) {
		 	//[slide image_width="" image_height="" link="" alt_text="" title="" auto_resize="true"]

			//defaults
			extract($this->shortcode_atts(array(  
		       "image_width" => '940',
			   "image_height" => '246',
			   "link" => '#',
			   "alt_text" => 'slider image',
			   "auto_resize" => 'true',
			   "title" => ''   
			), $atts));

			//width and height
			if($image_width  == "")  $image_width = "940";
			if($image_height == "") $image_height = "246";

			//fix content
			$content = preg_replace('#<br \/>#', "",trim($content));
			$content = preg_replace('#<p>#', "",trim($content));
			$content = preg_replace('#<\/p>#', "",trim($content));
			$content = preg_replace('#<span class="url">#', "",trim($content));
			$content = preg_replace('#</span>#', "",trim($content));
		 
			if($link){
				$linkStart='<a href="'.$link.'">';
				$linkEnd='</a>';
			}

			$slide = $linkStart.'<img src="'.$content.'"  alt="'.$alt_text.'" width="'.$image_width.'" height="'.$image_height.'" title="'.$title.'">'.$linkEnd;

			return $slide;
		}

		/*
		* ------------------------------------------------- *
		*		Table
		* ------------------------------------------------- *
		*/
		function table($atts, $content = null ) {
			// [table col1="Title 1" col2="Title 2" col3="Title 3"]

			$cols = "";
			$content = $this->do_shortcode($content);	
			$content = $this->fixshortcode($content);
			$content = preg_replace('#<br \/>#', "",trim($content));
			$content = preg_replace('#<p>#', "",trim($content));
			$content = preg_replace('#<\/p>#', "",trim($content)); 

		    for($i=1;$i<count($atts)+1;$i++){
		        $col_name = $atts['col'.$i];
		        if($col_name){
		        	$cols .=   '<th>'.$col_name.'</th>';
		        }
		    }

			return '<table class="bordered-table zebra-striped tablesort"><thead><tr>'.$cols.'</tr></thead><tbody>'.$this->do_shortcode($content).'</tbody></table>';
		}

		function line($atts, $content = null) {
		 	// [line][/line]

			//fix content
			$content = preg_replace('#<br \/>#', "",trim($content));
			$content = preg_replace('#<p>#', "",trim($content));
			$content = preg_replace('#<\/p>#', "",trim($content));
			$content = preg_replace('#<span class="url">#', "",trim($content));
			$content = preg_replace('#</span>#', "",trim($content));

			return '<tr>'.$this->do_shortcode($content).'</tr>';
		}

		function col($atts, $content = null) {
		 	// [col][/col]

			//fix content
			$content = preg_replace('#<br \/>#', "",trim($content));
			$content = preg_replace('#<p>#', "",trim($content));
			$content = preg_replace('#<\/p>#', "",trim($content));
			$content = preg_replace('#<span class="url">#', "",trim($content));
			$content = preg_replace('#</span>#', "",trim($content));

			return '<td>'.$this->do_shortcode($content).'</td>';
		}

	}

?>