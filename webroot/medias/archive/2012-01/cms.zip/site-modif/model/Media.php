<?php

	class Media extends Model {

		var $allowed_types = array(
			'image'   => array('image/pjpeg', 'image/jpeg', 'image/gif', 'x-png'),
			'pdf'     => array('application/pdf'),
			'archive' => array('application/zip'),
			'text'    => array('text/plain'),
			'video'   => array('video/x-msvideo', 'video/quicktime', 'video/mpeg'),
			'csv'     => array('text/comma-separated-values'),
			'word'    => array('vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/msword')
		);

		/**
		* Fonction permettant de tester si un type de fichier
		* est autoriser pour l'upload
		* @param string
		* @return bolean
		**/
		function fileCheck($mime){
			foreach ($this->allowed_types['image'] as $key) {
				if($key === $mime) return 'image';
			}
			foreach ($this->allowed_types['pdf'] as $key) {
				if($key === $mime) return 'pdf';
			}
			foreach ($this->allowed_types['archive'] as $key) {
				if($key === $mime) return 'archive';
			}
			foreach ($this->allowed_types['video'] as $key) {
				if($key === $mime) return 'video';
			}
			foreach ($this->allowed_types['csv'] as $key) {
				if($key === $mime) return 'csv';
			}
			foreach ($this->allowed_types['word'] as $key) {
				if($key === $mime) return 'word';
			}
			return FALSE;
		}

	}

?>