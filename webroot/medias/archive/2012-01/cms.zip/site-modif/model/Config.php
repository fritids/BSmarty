<?php

	class Config extends Model {

	}

?>