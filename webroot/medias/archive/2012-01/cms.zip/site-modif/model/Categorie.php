<?php
	
	class Categorie extends Model {
		

	}

?>