<?php

	class Page extends Model {
		

	}

?>