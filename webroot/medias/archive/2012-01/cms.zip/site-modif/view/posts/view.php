<?php $title_for_layout = $post->name; ?>

<h1><?php echo $post->name; ?></h1>
<p><?php echo $post->content; ?></p>