<div class="page-header">
	<h1>Réglages du TREE</h1>
</div>

<div class="row">
	<h3>L'arbre complet</h3>
	<?php echo $theTree['html']; ?>
</div>

<div class="row">
    <ul class="tabs">
        <li class="active"><a href="#tabaddnode">Ajouter un élément parent</a></li>
        <li><a href="#tabaddleaf">Ajouter un élément enfant</a></li>
        <li><a href="#tabmovenode">Déplacer un élément</a></li>
        <li><a href="#tabeditnode">Modifier un élément</a></li>
        <li><a href="#tabdelnode">Supprimer un élément</a></li>
    </ul>

    <div class="pill-content">
        <div class="active" id="tabaddnode">
            <!-- ADD new node !-->
            <form action="<?php echo Router::url('admin/tree/add/'); ?>" method="post">
                <input type="hidden" name="add_new_node" value="1">

                <?php echo $this->Form->input('name', 'Nom:'); ?>
                <?php echo $this->Form->select('id', 'Aprés:', $allThings); ?>

                <div class="clearfix">
                    <div class="input">
                    <input type="submit" class="btn primary" value="Ajouter">
                    </div>
                </div>
            </form>
            <!-- End ADD new node !-->
        </div>
        <div id="tabaddleaf">
            <!-- ADD new leaf !-->
            <form action="<?php echo Router::url('admin/tree/add/'); ?>" method="post">
                <input type="hidden" name="add_new_leaf" value="1">

                <?php echo $this->Form->input('name', 'Nom:'); ?>
                <?php echo $this->Form->select('id', 'Dans:', $allLeaves); ?>

                <div class="clearfix">
                    <div class="input">
                    <input type="submit" class="btn primary" value="Ajouter">
                    </div>
                </div>
            </form>
            <!-- End ADD new leaf !-->
        </div>
        <div id="tabmovenode">
            <!-- EDIT new node !-->
            <form action="<?php echo Router::url('admin/tree/move/'); ?>" method="post">
                <input type="hidden" name="move" value="1">

                <?php echo $this->Form->select('move', 'Déplacer:', $allThings); ?>
                <?php echo $this->Form->select('target', 'Dans:', $allThings); ?>

                <div class="clearfix">
                    <div class="input">
                    <input type="submit" class="btn primary" value="Déplacer">
                    </div>
                </div>
            </form>
            <!-- End EDIT new node !-->
        </div>
        <div id="tabeditnode">
            <!-- EDIT new node !-->
            <form action="<?php echo Router::url('admin/tree/edit/'); ?>" method="post">
                <input type="hidden" name="edit" value="1">

                <?php echo $this->Form->select('id', 'Selection:', $allThings); ?>
                <?php echo $this->Form->input('name', 'Modifier en:'); ?>

                <div class="clearfix">
                    <div class="input">
                    <input type="submit" class="btn primary" value="Modifier">
                    </div>
                </div>
            </form>
            <!-- End EDIT new node !-->
        </div>
        <div id="tabdelnode">
            <!-- DELETE node recursivly !-->
            <form action="<?php echo Router::url('admin/tree/delete/'); ?>" method="post">
                <input type="hidden" name="delete" value="1">

                <?php echo $this->Form->select('id', 'Sélection:', $allThings); ?>

                <div class="clearfix">
                    <div class="input">
                    <input type="submit" class="btn primary" value="Supprimer">
                    </div>
                </div>
            </form>
            <!-- End DELETE node recursivly !-->
        </div>
    </div>

    <hr>

</div>