<table class="zebra-striped tablesort">
	<thead>
		<tr>
			<th>Preview</th>
			<th>Titre</th>
			<th>Type</th>
			<th>URL</th>
			<th>Actions</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($medias as $k=>$v): ?>
		<tr>
			<td>
				<a href="#" title="<?php echo $v->name; ?>">
					<?php
						$imageSrc = "#";
						if($v->type == "image")   $imageSrc = Router::webroot('medias/'.$v->type.'/' . $v->file);
						if($v->type == "word")    $imageSrc = Router::webroot('images/icons/word.png');
						if($v->type == "archive") $imageSrc = Router::webroot('images/icons/archive.png'); 
						if($v->type == "text")    $imageSrc = Router::webroot('images/icons/text.png');
						if($v->type == "video")   $imageSrc = Router::webroot('images/icons/video.png'); 
						if($v->type == "csv")     $imageSrc = Router::webroot('images/icons/csv.png');					
					?>
					<img src="<?php echo $imageSrc; ?>" alt="<?php echo $v->name; ?>" height="32" />
				</a>
			</td>
			<td><?php echo $v->name; ?></td>
			<td><?php echo $v->type; ?></td>
			<td><?php echo Router::webroot('medias/'.$v->type.'/' . $v->file); ?></td>
			<td>
				<a onclick="return confirm('Voulez-vous vraiment supprimer ce fichier ?');" href="<?php echo Router::url('admin/medias/delete/' . $v->id); ?>">Supprimer</a>
			</td>
		</tr>
		<?php endforeach ?>
	</tbody>
</table>

<div class="page-header">
	<h1>Ajouter un fichier</h1>
</div>

<form action="<?php echo Router::url('admin/medias/index/'); ?>" method="post" enctype="multipart/form-data">
	<?php echo $this->Form->input('file', 'Fichier', array('type'=>'file')); ?>
	<?php echo $this->Form->input('name', 'Titre'); ?>
	<div class="actions">
		<input type="submit" value="Envoyer" class="btn primary">
	</div>
<form>