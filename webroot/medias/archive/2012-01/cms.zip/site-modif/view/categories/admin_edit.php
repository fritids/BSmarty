<div class="page-header">
	<h1>Editer une catégorie</h1>
</div>

<form action="<?php echo Router::url('admin/categories/edit/' . $id); ?>" method="post" >
	<?php echo $this->Form->input('name', 'Titre'); ?>
	<?php echo $this->Form->input('slug', 'Slug'); ?>
	<?php echo $this->Form->input('id', 'hidden'); ?>
	<?php echo $this->Form->input('type', 'Type'); ?>
	<div class="actions">
		<input type="submit" class="btn primary" value="Envoyer" >
	</div>
</form>