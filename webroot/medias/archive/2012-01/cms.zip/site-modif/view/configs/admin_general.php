<div class="page-header">
	<h1>Editer les options générales du site</h1>
</div>

<?php 

	foreach($data as $k=>$v):
?>
	<h3><?php echo $v->name; ?></h3>
	<form action="<?php echo Router::url('admin/configs/general/'); ?>" method="post" >
		
		<?php echo $this->Form->input('id', 'hidden', array('value' => $v->id)); ?>
		<?php echo $this->Form->input('name', 'hidden', array('value' => $v->name)); ?>
		<?php echo $this->Form->input('value', 'Value', array('value' => $v->value)); ?>
		<?php echo $this->Form->input('slug', 'Slug', array('value' => $v->slug)); ?>
		<?php echo $this->Form->input('category', 'Category', array('value' => $v->category)); ?>
		<div class="actions">
			<input type="submit" class="btn primary" value="Envoyer" >
		</div>
	</form>
<?php
	endforeach;
?>
