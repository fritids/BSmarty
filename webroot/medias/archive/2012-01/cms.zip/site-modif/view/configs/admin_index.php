<div class="page-header">
	<h1>Réglages du CMS</h1>
</div>
<div class="row">
	<div class="span6">
	<h2>Général</h2>
		<p>Configuration du nom du site web, du slogan, du nombre de billet par page ...</p>
		<p><a href="<?php echo Router::url('admin/configs/general'); ?>" class="btn">Configurer »</a></p>
	</div>
	<div class="span5">
		<h2>SEO</h2>
		<p>Configuration interne du CMS. Dans cette section vous pouvez modifiler les différents mots clés utilisés dans les balies de site, mais aussi sa description, son auteur, son copyright ...</p>
		<p><a href="#" class="btn">Configurer »</a></p>
	</div>
	<div class="span5">
		<h2>Heading</h2>
		<p>Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</p>
		<p><a href="#" class="btn">Configurer »</a></p>
	</div>
</div>