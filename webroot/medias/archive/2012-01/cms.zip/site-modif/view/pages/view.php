<?php $title_for_layout = $page->name; ?>

<h1><?php echo $page->name; ?></h1>
<p><?php echo $page->content; ?></p>