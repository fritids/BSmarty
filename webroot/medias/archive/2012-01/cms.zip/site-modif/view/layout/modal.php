<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang"fr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title><?php echo isset($title_for_layout) ? $title_for_layout : 'Administration'; ?></title>
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="http://twitter.github.com/bootstrap/1.4.0/bootstrap.min.css">

  </head>

  <body>
      <?php echo $this->Session->flash(); ?>
      <?php echo $content_for_layout; ?>
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
      <script type="text/javascript" src="<?php echo Router::webroot('js/table.sorter.min.js'); ?>"></script>
      <script type="text/javascript">
        jQuery(document).ready(function() {
          $('.tablesort').tablesorter();
        });
      </script>
  </body>
</html>
