<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang"fr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title><?php echo isset($title_for_layout) ? $title_for_layout : 'Administration'; ?></title>
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="stylesheet" href="http://twitter.github.com/bootstrap/1.3.0/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo Router::webroot('css/flick/jquery-ui.css'); ?>">
    <link rel="stylesheet" href="<?php echo Router::url(''); ?>css/style.css">

  </head>

  <body>

    <div class="topbar" style="position: static;">
      <div class="topbar-inner">
        <div class="container">
          <h3><a href="<?php echo Router::url('admin/posts/index'); ?>">Administration</a></h3>
          <ul class="nav">
              <li><a href="<?php echo Router::url('admin/posts/index'); ?>" title="">Articles</a></li>
              <li><a href="<?php echo Router::url('admin/pages/index'); ?>" title="">Pages</a></li>
              <li><a href="<?php echo Router::url('admin/categories/index'); ?>" title="">Catégories</a></li>
              <li><a href="<?php echo Router::url('admin/configs/index'); ?>" title="">Configurations</a></li>
              <li><a href="<?php echo Router::url('/'); ?>" title="">Voir le site</a></li>
              <li><a href="<?php echo Router::url('users/logout'); ?>" title="">Se déconnecter</a></li>
          </ul>
        </div>
      </div>
    </div>

    <div class="container" style="padding-top: 60px;">
      <?php echo $this->Session->flash(); ?>
      <?php echo $content_for_layout; ?>
    </div>

  </body>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
  <script type="text/javascript" src="<?php echo Router::webroot('js/table.sorter.min.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo Router::webroot('js/bootstrap-tabs.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo Router::webroot('js/slug.js'); ?>"></script>
  <script type="text/javascript">
      jQuery(document).ready(function() {
          $("#inputcreated").datepicker({dateFormat: 'yy-mm-dd'});
          $(".tablesort").tablesorter();
          $('.tabs').tabs();
          $("#inputname").slug({hide:false,slug:'#inputslug'});

          var $explorer = $('<div></div>').load('<?php echo Router::url('admin/medias/index'); ?>').dialog({autoOpen: false, title: 'Basic Dialog', height: 600, width: 800});
          $('#explorer').click(function() {
            $explorer.dialog('open');
            return false;
          });
      });
  </script>

</html>
