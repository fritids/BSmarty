<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang"fr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title><?php echo isset($layoutInformations) ? $layoutInformations['site_title']->value : 'Mon site'; ?></title>
    <meta name="description" content="<?php echo isset($layoutInformations) ? $layoutInformations['site_description']->value : 'Ma description'; ?>">
    <meta name="author" content="">
    <meta name="keywords" content="<?php echo isset($layoutInformations) ? $layoutInformations['site_keywords']->value : 'Mes mots clés'; ?>"> 

    <link rel="stylesheet" href="http://twitter.github.com/bootstrap/1.4.0/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo Router::webroot('css/flick/jquery-ui.css'); ?>">
    <link rel="stylesheet" href="<?php echo Router::webroot('css/slider/themes/default/default.css'); ?>">
    <link rel="stylesheet" href="<?php echo Router::webroot('css/slider/themes/pascal/pascal.css'); ?>">
    <link rel="stylesheet" href="<?php echo Router::webroot('css/slider/themes/orman/orman.css'); ?>">
    <link rel="stylesheet" href="<?php echo Router::webroot('css/slider/slider.css'); ?>">
    <link rel="stylesheet" href="<?php echo Router::url(''); ?>css/style.css">

  </head>

  <body>

    <div class="topbar" style="position: static;">
      <div class="topbar-inner">
        <div class="container">
          <h3><a href="<?php echo Router::url(''); ?>"><?php echo isset($layoutInformations) ? $layoutInformations['site_title']->value : 'Mon site'; ?></a></h3>
          <ul class="nav">
            <?php $pagesMenu = $this->request('Pages', 'getMenu'); ?>
            <?php foreach($pagesMenu as $p): ?>
              <li><a href="<?php echo Router::url("pages/view/id:{$p->id}/slug:{$p->slug}"); ?>" title="<?php echo $p->name; ?>"><?php echo $p->name; ?></a></li>
            <?php endforeach; ?>

              <li><a href="<?php echo Router::url('posts/index'); ?>">Actualités</a></li>
              <?php
                if($this->Session->user('role') == 'admin'):
              ?>
                <li><a href="<?php echo Router::url('admin/posts/index'); ?>">Administration</a></li>
                <li><a href="<?php echo Router::url('users/logout'); ?>" title="">Se déconnecter</a></li>
              <?php
                endif;
              ?>             
          </ul>
        </div>
      </div>
    </div>

    <div class="container" style="padding-top: 60px; padding-bottom: 50px;">
      <?php echo $this->Session->flash(); ?>
      <?php echo $content_for_layout; ?>

      <footer>
        <p>&copy; Company 2011</p>
      </footer>
    </div>

  </body>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
  <script type="text/javascript" src="<?php echo Router::webroot('js/table.sorter.min.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo Router::webroot('js/jquery.nivo.slider.pack.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo Router::webroot('js/qaptcha/jquery/jquery-ui-widget.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo Router::webroot('js/qaptcha/jquery/jquery-ui-touch.js'); ?>"></script>
  <script type="text/javascript" src="<?php echo Router::webroot('js/qaptcha/jquery/QapTcha.jquery.js'); ?>"></script>
  <script type="text/javascript">
      jQuery(document).ready(function() {
          $('.tablesort').tablesorter();
          $('.tabs').tabs();
          $('.accordion').accordion();
          $('.slider').nivoSlider();
          $('.QapTcha').QapTcha({PHPfile:"<?php echo Router::webroot('js/qaptcha/php/Qaptcha.jquery.php'); ?>"});
      });
  </script>
</html>
