<?php
	require 'Session.php';
	require 'Form.php';
	require 'functions.php';
	require 'Router.php';
	
	require ROOT . DS . 'config' . DS . 'conf.php';

	require 'Request.php';
	require 'Model.php';
	require 'Controller.php';
	require 'Dispatcher.php';

?>