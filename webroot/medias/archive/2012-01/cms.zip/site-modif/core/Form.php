<?php

	class Form{
		
		public $controller;
		public $errors;

		public function __construct($controller){
			$this->controller = $controller;
		}

		public function input($name, $label, $options = array()){
			$error = FALSE;
			$classError = '';
			if(isset($this->errors[$name])){
				$error = $this->errors[$name];
				$classError = ' error';
			}
			if(!isset($this->controller->request->data->$name)){
				$value = '';
				if(isset($options['value']) && !empty($options['value'])){
					$value = $options['value'];
				}
			}else{
				$value = $this->controller->request->data->$name;
			}
			if($label == 'hidden'){
				return '<input type="hidden" name="' . $name . '" value="' . $value . '" >';
			}

			$html = '<div class="clearfix' . $classError . '">
						<label for="input' . $name . '">' . $label . '</label>
						<div class="input">';
			$attr = ' ';
			foreach($options as $k=>$v){ if($k!='type'){
				$attr .= "$k=\"$v\"";
			}}
			if(!isset($options['type'])){
				$html .= '<input type="text" id="input' . $name . '" name="' . $name . '" value="' . $value . '" ' . $attr . ' >';
			}elseif($options['type'] == 'texarea'){
				$html .= '<textarea id="input' . $name . '" name="' . $name . '" ' . $attr . ' >' . $value . '</textarea>';
			}elseif($options['type'] == 'checkbox'){
				$html .= '<input type="hidden" name="' . $name . '" value="0"><input type="checkbox" name="' . $name . '" value="1" ' . (empty($value)? '' : 'checked') . ' />';
			}elseif($options['type'] == 'file'){
				$html .= '<input type="file" class="input-file" id="input' . $name . '" name="' . $name . '" ' . $attr . ' >';
			}
			elseif($options['type'] == 'password'){
				$html .= '<input type="password" id="input' . $name . '" name="' . $name . '" value="' . $value . '" ' . $attr . ' >';
			}
			if($error){
				$html .= '<span class="help-inline">'. $error . '</span>';
			}

			$html .= '</div></div>';
			return $html;
		}

		function select($name, $label, $value, $options = array()){
			$error = FALSE;
			$classError = '';

			if(isset($this->errors[$name])){
				$error = $this->errors[$name];
				$classError = ' error';
			}
			if(!isset($this->controller->request->data->$name)){
				$focus = '';
				if(isset($options['focus']) && !empty($options['focus'])){
					$focus = $options['focus'];
				}
			}else{
				$focus = $this->controller->request->data->$name;
			}

			$html = '<div class="clearfix' . $classError . '">
						<label for="input' . $name . '">' . $label . '</label>
						<div class="input">';
			$attr = ' ';
			$html .= '<select id="input' . $name . '" name="' . $name . '" ' . $attr . ' >';

			foreach($value as $k){
				if($focus === $k->name){
					$html .= '<option value="' . $k->id . '" SELECTED>' . $k->name . '</option>';
				}
				$html .= '<option value="' . $k->id . '">' . $k->name . '</option>';
			}
			
			
            $html .= '</select>';
            $html .= '</div></div>';
			return $html;
		}

	}


?>