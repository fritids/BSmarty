<?php

	class CategoriesController extends Controller{
		
		function index(){
			$perPage = 10;
			$this->loadModel('Categorie');
			$d['categories'] = $this->Categorie->find(array(
				'limit' => ($perPage*($this->request->page-1)) . ',' . $perPage,
				'conditions' => 'type="post" OR type="page"',
				'orderBy' => 'name DESC'
			));
			$d['total'] = $this->Post->findCount($condition);
			$d['page'] = ceil($d['total']/$perPage);
			$this->set($d);
		}

		function view($id, $slug) {
			$this->loadModel('Categorie');
			$d['Categorie'] = $this->Post->findFirst(array(
				'conditions' => array('id' => $id)
			));
			if(empty($d['Categorie'])){
				$this->e404('Categorie introuvable');
			}
			if($slug != $d['Categorie']->slug){
				$this->redirect("categories/view/id:$id/slug:" . $d['Categorie']->slug, 301);
			}
			$this->set($d);
		}

		/**
		* ADMIN
		**/
		function admin_index(){
			$perPage = 10;
			$this->loadModel('Categorie');
			$d['categories'] = $this->Categorie->find(array(
				'limit' => ($perPage*($this->request->page-1)) . ',' . $perPage,
				'conditions' => 'type="post" OR type="page"',
				'orderBy' => 'name DESC'
			));
			$d['total'] = $this->Categorie->findCount();
			$d['page'] = ceil($d['total']/$perPage);
			$this->set($d);
		}

		/**
		* Permet d'éditer un article
		**/
		function admin_edit($id = NULL){
			$this->loadModel('Categorie');
			if($id === NULL){
				$categorie = $this->Categorie->findFirst(array(
					'conditions' => array('type' => 'unknown')
				));
				if(!empty($categorie)){
					$id = $categorie->id;
				}else{
					$this->Categorie->save(array(
						'type' => 'unknown'
					));
					$id = $this->Categorie->id;	
				}
			}
			$d['id'] = $id;
			if($this->request->data){
				$this->Categorie->save($this->request->data);
				$this->Session->setFlash('La catégorie a bien été modifié');
				$this->redirect('admin/categories/index');

			}else{
				$this->request->data = $this->Categorie->findFirst(array(
					'conditions' => array('id' => $id)
				));
			}
			$this->set($d);
		}

		/**
		* Permet de supprimer un article
		**/
		function admin_delete($id){
			$this->loadModel('Categorie');
			$this->Categorie->delete($id);
			$this->Session->setFlash('La catégorie a bien été supprimé');
			$this->redirect('admin/categories/index');
		}

	}

?>