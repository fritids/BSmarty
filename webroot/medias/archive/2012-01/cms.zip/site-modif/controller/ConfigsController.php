<?php

	class ConfigsController extends Controller {
		
		function admin_index(){
			
		}

		/**
		* Permet de gérer toutes les options générales du CMS
		**/
		function admin_general() {
			$this->loadModel('Config');
			if($this->request->data){
				$this->Config->save($this->request->data);
				$this->redirect('admin/configs/general');

			}
			$d['data']= $this->Config->find(array(
				'conditions' => array('category' => 'admin_general')
			));
			$this->set($d);
		}
	}
?>