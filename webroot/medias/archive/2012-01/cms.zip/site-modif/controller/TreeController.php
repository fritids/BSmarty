<?php

	class TreeController extends Controller{

		/**
		* ---- ADMIN ----
		**/
		function admin_index(){
			$this->loadModel('Tree');

			$d['theTree']   = $this->Tree->buildMenu(); // Créer l'arbre
			$d['allNodes']  = $this->Tree->allNodes(); // Donne la liste de tous les noeuds
			$d['allLeaves'] = $this->Tree->leafNodes(); // Donne la liste des toutes les feuilles
			$d['allThings'] = array_merge($d['allNodes'], $d['allLeaves']); // Donne une liste contenant toutes les feuilles et tous les noeuds

			$this->set($d);
		}

		/**
		* Permet de déplacer un élément
		**/
		function admin_move(){
			$this->loadModel('Tree');
			if($this->request->data){
				if(isset($this->request->data->move)){
					$moving = $this->Tree->moveNode($this->request->data->move, $this->request->data->target);
					if($moving){
						$this->Session->setFlash('L\'élément a bien été déplacé');
						$this->redirect('admin/tree/index');
					}
				}
			}
		}

		/**
		* Permet de modifier un élément
		**/
		function admin_edit(){
			$this->loadModel('Tree');
			if($this->request->data){
				if(isset($this->request->data->edit)){ // Modification d'un élément
					$nodeInfos = array_shift($this->Tree->idToNode($this->request->data->id));
					$nodeInfos['field'] = array_search($nodeInfos['name'], $nodeInfos);
					$nodeInfos['value'] = $this->request->data->name;
					unset($nodeInfos['name']);
					if($this->Tree->basicEdit($nodeInfos)){
						$this->Session->setFlash('L\'élément a bien été modifié');
						$this->redirect('admin/tree/index');
					}
				}
			}
		}

		/**
		* Permet d'ajouter l'item selon son type
		**/
		function admin_add(){
			$this->loadModel('Tree');
			if($this->request->data){
				if(isset($this->request->data->add_new_leaf)){ // Ajout d'une feuille
					$nodeParentInfos = array_shift($this->Tree->idToNode($this->request->data->id));
					if($this->Tree->addChildNode($nodeParentInfos['name'], $this->request->data->name)){
						$this->Session->setFlash('L\'élément a bien été ajouté');
						$this->redirect('admin/tree/index');
					}
				}elseif(isset($this->request->data->add_new_node)){ // Ajout d'un noeud
					$nodeAfterInfos = array_shift($this->Tree->idToNode($this->request->data->id));
					if($this->Tree->addNode($nodeAfterInfos['name'], $this->request->data->name)){
						$this->Session->setFlash('L\'élément a bien été ajouté');
						$this->redirect('admin/tree/index');
					}
				}else{
					$this->Session->setFlash('Le type d\'ajout est inconnu.', 'important');
					$this->redirect('admin/tree/index');
				}

			}
		}

		/**
		* Permet de supprimer l'item selon son type
		**/
		function admin_delete(){
			$this->loadModel('Tree');
			if($this->request->data){
				if(isset($this->request->data->delete)){ // Ajout d'une feuille
					$nodeInfos = array_shift($this->Tree->idToNode($this->request->data->id));
					if($this->Tree->deleteNodeRecursive($nodeInfos['name'])){
						$this->Session->setFlash('L\'élément a bien été supprimé');
						$this->redirect('admin/tree/index');
					}
				}else{
					$this->Session->setFlash('Le type de suppression est inconnu.', 'important');
					$this->redirect('admin/tree/index');
				}
			}
		}
	}
?>