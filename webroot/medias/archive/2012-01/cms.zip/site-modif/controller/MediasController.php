<?php
	class MediasController extends Controller{
		
		 // + pdf video zip rar 7zip

		function admin_index(){
			$this->loadModel('Media');
			if($this->request->data && !empty($_FILES['file']['name'])){
				//debug($_FILES['file']['type']); die();
				$check = $this->Media->fileCheck($_FILES['file']['type']);
				if($check){ // L'extension du fichier est autorisée
					$dir = WEBROOT.DS.'medias/'.$check.DS.date('Y-m');
					if(!file_exists($dir)) mkdir($dir,0777);
					move_uploaded_file($_FILES['file']['tmp_name'],$dir.DS.$_FILES['file']['name']);
					$this->Media->save(array(
						'name' => $this->request->data->name,
						'file' => date('Y-m') . '/' . $_FILES['file']['name'],
						'post_id' => '0',
						'type' => $check
					));
					$this->Session->setFlash("Le fichier à bien été uploadé");
				}else{
					$this->Session->setFlash("ERREUR : Le fichier n'a pu être chargé, verfier l'extension", "error");
				}
				
			}
			$this->layout = 'modal';
			$d['medias'] = $this->Media->find();
			$this->set($d);
		}

		function admin_posts($id){
			$this->loadModel('Media');
			if($this->request->data && !empty($_FILES['file']['name'])){
				if(strpos($_FILES['file']['type'], 'image') !== FALSE){
					$dir = WEBROOT . DS . 'medias/images' . DS . date('Y-m');
					if(!file_exists($dir)) mkdir($dir,0777);
					move_uploaded_file($_FILES['file']['tmp_name'],$dir . DS . $_FILES['file']['name']);
					$this->Media->save(array(
						'name' => $this->request->data->name,
						'file' => date('Y-m') . '/' . $_FILES['file']['name'],
						'post_id' => $id,
						'type' => 'img'
					));
					$this->Session->setFlash("L'image à bien été uploadé");
				}else{
					$this->Form->errors['file'] = "Le fichier n'est pas une image";
				}
			}
			$this->layout = 'modal';
			$d['images'] = $this->Media->find(array(
				'conditions' => array('post_id' => $id )));
			$d['post_id'] = $id;
			$this->set($d);
		}

		function admin_delete($id){
			$this->loadModel('Media');
			$media = $this->Media->findFirst(array(
				'conditions' => array('id' => $id)
			));
			unlink(WEBROOT . DS . 'img' . DS . $media->file);
			$this->Media->delete($id);
			$this->Session->setFlash("Le media a bien été supprimé");
			$this->redirect('admin/medias/index/' . $media->post_id);
		}

	}


?>