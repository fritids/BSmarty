<?php

	class ContactController extends Controller{

		function index(){
			if($this->request->data){
				$this->loadModel('Contact');
				if($this->Contact->validates($this->request->data) && isset($this->request->data->iQapTcha) && empty($this->request->data->iQapTcha) && isset($_SESSION['iQaptcha']) && $_SESSION['iQaptcha']){
					unset($_SESSION['iQaptcha']);
					$this->loadModel('Config');
					$from = $this->Config->findFirst(array(
							'fields' => 'value',
							'conditions' => array('slug' => 'emailfrom', 'category' => 'admin_general')
						))->value;
					$to = $this->Config->findFirst(array(
							'fields' => 'value',
							'conditions' => array('slug' => 'emailto', 'category' => 'admin_general')
						))->value;

					$this->Contact->send($this->request->data, $from, $to);
					$this->Session->setFlash('Le message a bien été envoyé');
				}else{
					$this->Session->setFlash('Merci de corriger vos informations', 'error');
					
				}
				
			}
		}

	}
?>