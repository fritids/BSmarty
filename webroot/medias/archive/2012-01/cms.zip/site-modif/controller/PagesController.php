<?php

	class PagesController extends Controller {
		
		function view($id, $slug=NULL) {
			$this->loadModel('Post');
			$d['page'] = $this->Post->findFirst(array(
				'conditions' => array('online' => 1, 'id' => $id, 'type'=>'page')
			));
			if(empty($d['page'])){
				$this->e404('Page introuvable');
			}

			// Probleme de redirecation

			if($slug != $d['page']->slug){
				$this->redirect("page/view/id:$id/slug:" . $d['post']->slug, 301);
			}

			/**
			*  Implentation des shortcodes
			**/
			$this->loadModel(array('Shortcode', 'ThemeShortcode'));
			$this->ThemeShortcode->add_shortcode('tabs', 'tabulars');
			$this->ThemeShortcode->add_shortcode('tab', 'tab');
			$this->ThemeShortcode->add_shortcode('accordion', 'accordion');
			$this->ThemeShortcode->add_shortcode('pane', 'accordion_panel');
			$this->ThemeShortcode->add_shortcode('slider', 'slider');
			$this->ThemeShortcode->add_shortcode('slide', 'slide');
			$this->ThemeShortcode->add_shortcode('table', 'table');
			$this->ThemeShortcode->add_shortcode('line', 'line');
			$this->ThemeShortcode->add_shortcode('col', 'col');

			$d['page']->content = $this->ThemeShortcode->do_shortcode($d['page']->content);


			$this->set($d);	
		}

		/**
		* Permet de récupérer les pages pour le menu
		**/
		function getMenu(){
			$this->loadModel('Post');
			return $this->Post->find(array(
				'conditions' => array('online' => 1, 'type' => 'page')
			));
		}

		/**
		* ADMIN
		**/
		function admin_index(){
			$perPage = 10;
			$this->loadModel('Post');
			$condition = array('type' => 'page');
			$d['posts'] = $this->Post->find(array(
				'fields' => 'id,id_cat,name,online',
				'conditions' => $condition,
				'limit' => ($perPage*($this->request->page-1)) . ',' . $perPage,
				'orderBy' => 'created DESC'
			));

			$this->loadmodel('Categorie');
			foreach($d['posts'] as $k){
				$condition_categorie = array('fields' => 'id, name', 'conditions' => array('id' => $k->id_cat));
				$k->cat_name = $this->Categorie->findFirst($condition_categorie)->name;
			}

			$d['total'] = $this->Post->findCount($condition);
			$d['page'] = ceil($d['total']/$perPage);
			$this->set($d);
		}

		/**
		* Permet d'éditer un article
		**/
		function admin_edit($id = NULL){
			$this->loadModel('Post');
			if($id === NULL){
				$post = $this->Post->findFirst(array(
					'conditions' => array('online' => -1)
				));
				if(!empty($post)){
					$id = $post->id;
				}else{
					$this->Post->save(array(
						'online' => -1
					));
					$id = $this->Post->id;	
				}
			}
			$d['id'] = $id;
			if($this->request->data){
				if($this->Post->validates($this->request->data)){
					$this->request->data->type = 'page';
					if(empty($this->request->data->created)){
						$this->request->data->created = date('Y-m-d h:i:s');
					}else{
						$this->request->data->created = date($this->request->data->created . ' h:i:s');
					}

					$this->Post->save($this->request->data);
					$this->Session->setFlash('Le contenu a bien été modifié');
					$this->redirect('admin/pages/index');
				}else{
					$this->Session->setFlash('Merci de corriger vos informations', 'error');
				}

			}else{
				$this->request->data = $this->Post->findFirst(array(
					'conditions' => array('id' => $id)
				));
			}
			$this->loadmodel('Categorie');
			$d['categories']['list'] = $this->Categorie->find(array(
				'conditions' => array('type' => 'page')
			));
			$this->set($d);
		}

		/**
		* Permet de supprimer un article
		**/
		function admin_delete($id){
			$this->loadModel('Post');
			$this->Post->delete($id);
			$this->Session->setFlash('Le contenu a bien été supprimé');
			$this->redirect('admin/posts/index');
		}

		/**
		* Permet de lister les contenus
		**/
		function admin_tinymce(){
			$this->loadModel('Post');
			$this->layout = 'modal';
			$d['posts'] = $this->Post->find();
			$this->set($d);
		}
	}

?>